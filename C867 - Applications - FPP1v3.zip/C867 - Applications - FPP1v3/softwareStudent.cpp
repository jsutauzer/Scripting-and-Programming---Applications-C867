#include "softwareStudent.h"

Degree SoftwareStudent::getDegree()
{
	return degree;
}
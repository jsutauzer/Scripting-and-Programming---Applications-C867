#include "securityStudent.h"

Degree SecurityStudent::getDegree()
{
	return degree;
}
#include "networkStudent.h"

Degree NetworkStudent::getDegree()
{
	return degree;
}
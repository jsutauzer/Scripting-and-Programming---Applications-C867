#pragma once

enum Degree { NETWORK, SECURITY, SOFTWARE };
